import SwiftUI

struct ContentView: View {
    
    @EnvironmentObject var viewModel: FormsViewModel
    
    var content: some View {
        
        ZStack {
            VStack(spacing: 15) {
                HStack(spacing: -5) {
                    Button {
                        viewModel.isRunning.toggle()
                    } label: {
                        Image(systemName: "pause")
                            .font(.system(size: 20).bold())
                            .foregroundColor(.white)
                            .frame(maxWidth: 40, maxHeight: 40)
                            .background(Color.gray)
                            .cornerRadius(12)
                    }
                    .padding(.vertical, 20)
                    .padding()
                    
                    Text("\(viewModel.counter_of_right_answer) / 5")
                        .font(.system(.title3).bold())
                        .foregroundColor(.white)
                    Spacer()
                }
                
                Spacer()
                
                Text(viewModel.question.question_translate)
                    .multilineTextAlignment(.center)
                    .font(.custom("Avenir", size: 22).bold())
                    .foregroundColor(.yellow)
                
                Text(viewModel.question.question)
                    .multilineTextAlignment(.center)
                    .font(.custom("Avenir", size: 26).bold())
                    .foregroundColor(.white)
                
                ForEach(viewModel.question.choices, id: \.self) { choice in
                    ButtonCell(choice: choice)
                }
                Spacer()
            }
            .background(Image("pic2").blur(radius: 10)).ignoresSafeArea()
            
            //вместо true переменная isRunning
            if !viewModel.isRunning {
                VStack(spacing: 15) {
                    HStack(spacing: -5) {
                        Button {
                            viewModel.isRunning.toggle()
                        } label: {
                            Image(systemName: "clear")
                                .font(.system(size: 20).bold())
                                .foregroundColor(.white)
                                .frame(maxWidth: 40, maxHeight: 40)
                                .background(Color.gray)
                                .cornerRadius(12)
                        }
                        .padding(.vertical, 20)
                        .padding()

                        Text("Пауза")
                            .font(.system(.title3).bold())
                            .foregroundColor(.white)
                        Spacer()
                    }
                    
                    Spacer()
                    
                    VStack(spacing: 13) {
                        ButtonSettings(text: "Начать сначала",
                                       color: .white)
                        ButtonSettings(text: "Читать правило",
                                       color: .white)
                        
                        // Читать правило, можно вернуться
                        ButtonSettings(text: "Выйти",
                                       color: .white)
                        Button {
                            viewModel.isRunning.toggle()
                        } label: {
                            ButtonSettings(text: "Продолжить",
                                           color: .yellow)
                        }
                    }
                    
                    Spacer()
                }
                .background(Image("pic7").blur(radius: 20)).ignoresSafeArea()
            }
        }.navigationBarBackButtonHidden(true)
            .navigationBarHidden(true)
    }
    var body: some View {
        VStack {
            if viewModel.gameOver {
                FormTestResultView()
            } else {
                content
            }
        }
    }
}

struct ButtonCell: View {
    
    @State var new_button_color = Color.white
    @EnvironmentObject var viewModel: FormsViewModel
    
    let choice: String
    var body: some View {
        
        Button {
            let result = viewModel.checkAnswer(choice)
            new_button_color =  result ? .green : .red
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                new_button_color = .white
                viewModel.nextQuestions()
            }
        } label: {
            ButtonSettings(text: choice,
                           color: new_button_color)
        }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .environmentObject(FormsViewModel())
    }
}
