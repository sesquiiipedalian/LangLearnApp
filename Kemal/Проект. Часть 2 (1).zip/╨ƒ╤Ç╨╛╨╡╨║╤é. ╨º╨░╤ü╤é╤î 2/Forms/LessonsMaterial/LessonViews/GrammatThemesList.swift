import SwiftUI

struct GrammatThemesList: View {
    var body: some View {
        VStack {
            Text("GrammatThemesList")
        }
    }
}

struct GrammatThemesList_Previews: PreviewProvider {
    static var previews: some View {
        GrammatThemesList()
    }
}
